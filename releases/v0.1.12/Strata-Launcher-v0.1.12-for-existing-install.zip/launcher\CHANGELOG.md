# Strata 辅助启动器更新日志

启动器版本独立于 Strata 官方版本。当前发布版本为 `0.1.12`；该版针对本机 Strata `v0.2.7.1` 源码安装版校验。发布时本机 Qwen 引擎 `0.1.52`（本修复走通后由 `0.1.50` 升级，旧引擎保留在 `engine\.previous`）、DeepSeek 引擎 `0.1.52`。后续本机版本以实际安装状态为准。

## 0.1.12 — 2026-10-29

- 修复「更新引擎（Qwen）」替换前核对签名暂存版本这一步（0.1.11 新加的代码）：那条 `python -c` 命令用双引号写 `engine-feed`，PowerShell 5.1 拼装原生进程参数时**会丢掉参数内部的双引号**，Python 实际收到 `ec.resolve(setup.home() / engine-feed, full=True)`，按减法解析后报 `NameError: name 'engine' is not defined`，退出码 1。脚本又把捕获到的 stderr 当成版本号，所以用户看到的是「签名暂存引擎版本 python.exe : Traceback … 与官方提供的 0.1.52 不一致；未替换本机 engine」。下载与验签其实已经成功（`engine-feed\engine\0.1.52-windows-x86_64-cuda-cuda13` 已就位并验签通过），只是没走到替换那一步。
  - 命令改成与同一函数里取暂存目录那条一致的写法：外层 PowerShell 双引号、内层 Python 单引号，PowerShell 不会改动单引号。
  - 退出码非 0 单独报错（`无法核对签名暂存引擎的版本：…`），不再把 traceback 冒充成版本号；版本不一致仍是原来的提示。
- 回归测试补进 `tests\Test-Strata-Launcher-EngineOnly.ps1`：断言替身 python **实际收到的参数**里必须是 `'engine-feed'`。原来的替身只判断参数中含 `ec.resolve`，引号被丢掉也照样返回版本号，所以 0.1.11 的 41 个 PowerShell 测试全过却没拦住这个故障。
- 记录一个改脚本时必须遵守的前提：仓库的 `.ps1` 带 UTF-8 BOM，去掉 BOM 后 Windows PowerShell 5.1 按 GBK 解析中文文案，整个脚本直接语法错误（`Unexpected token 'Strata'`），报错内容看起来与源码无关。
- 验证：`Test-Strata-Launcher-EngineOnly`（含新断言）与 `EngineVersion` / `EngineFeatures` / `EngineConfigPath` / `DeepSeekEngine` 共 5 个 PowerShell 测试通过；用真实暂存包实测修复后的探测命令返回 `0.1.52`（退出码 0），并用参数回显确认旧写法到达 python.exe 时引号已经丢失。**按本次要求省略完整本地验证**：Python 测试套件与其余 PowerShell 测试未重跑。
- **实机验收：**修复后的「更新引擎（Qwen）」在本机走通，Qwen 引擎 `0.1.50 → 0.1.52`（`engine\BUILD.json` 版本 `0.1.52`、commit `a42cc3d7df70`；旧引擎保留在 `engine\.previous`，其 `BUILD.json` 是 `0.1.50`；替换时间戳 22:02:49。官方 `--update` 在兼容下限 `0.1.46` 下不会替换引擎，所以替换来自签名暂存的 `engine_from_feed` 路径）。升级后真实启动 `qwen3.8-flash-next-iq3_s`，`/health` 报 `loaded: true`、`max_context: 262144`、`images: true`；日志记录一次 145,744 token 提示下生成 2,022 token / 22.975 s（88.0 tok/s，草稿接受 1,222/1,788）。DeepSeek 引擎同为 `0.1.52`（`engine-dsv41\0.1.52-windows-x86_64-cuda-cuda13`，模型配置已指向该目录）。**未做**：与 `0.1.50` 的速度对照、长对话与停止验收。

## 0.1.11 — 2026-10-29

- 官方更新始终以最新稳定 Release 及同系列补丁标签为源码目标，不再因分支有 upstream 而拉取未发布的 `main`。补丁标签以版本号和 Git 祖先关系识别，支持官方将补丁写在 Release 页面、但没有独立发布说明文件的情况（如 `v0.2.7.1`）。非 Git 源码副本会明确报错，避免只检查旧副本却显示更新完成。
- 对照官方 0.2.7.1 / Windows 引擎 0.1.52：新增 Qwen 长提示、12 GB NVIDIA、Radeon RX 9000 和 DeepSeek 加速开关；按模型、显卡和引擎版本显示，未更改的开关保留现有环境变量。
- DeepSeek 图像输入在引擎达到 0.1.52 且当前 pack 含视觉塔时可开关，保存为 `--vision on/off`；旧引擎或纯文本 pack 不会收到该参数。Qwen 的视觉配置仍由独立组件处理。
- Qwen 和 DeepSeek 引擎更新先比较签名源所提供的版本；已经最新时不重复替换，检查或下载失败时明确报错。Qwen 更新后核对签名暂存版本和安装版本，避免把旧缓存装回本机。
- 验证：41 个 PowerShell 与 139 个 Python 测试通过；运行副本 `-CheckOnly` 就绪、`-VerifyOnly` 通过。本版未安装 0.1.52 引擎，也未对新版图像与速度收益进行实机验收。

## 0.1.10 — 2026-10-26

- 修正 DeepSeek 引擎升级后的启动失败（0.1.9 只在“点更新按钮”时改配置，漏了另一种触发）：官方升级把引擎装到新的版本目录、删掉旧目录，而模型配置记的是绝对 `exe` 路径。如果升级时启动器窗口已经开着，它的「保存并启动」会把内存里的旧路径写回去（`Save-Settings` 的 `Json-Clone $cfg`），模型下一次启动就在 `serve\server.py` 的 CreateProcess 里失败（`FileNotFoundError: [WinError 2]`）。
  - **打开启动器时**就把指向已删除引擎目录的配置改到已安装的那一份，状态栏写“已修正 N 个模型配置的引擎路径”。
  - **保存之前**再校验一次，窗口开在升级之前也不会写回旧路径。
  - 只处理 `engine-dsv41` 下的绝对路径、且只在“配置里的引擎确实不存在”时动手；能正常启动的配置和 `engine\strata.exe`（Qwen）一概不碰，第二次执行零改动。
- 修复逻辑收到分享包共用的 `Strata-Launcher-Environment.ps1`（`Repair-StrataConfigEnginePath` / `Repair-StrataEngineConfigFiles`），更新脚本与启动器共用同一份，避免两处漂移。
- 发布工具（不打进分享包）：`git tag -d` 在标签不存在时向 stderr 写一行，PowerShell 5.1 在 `ErrorActionPreference=Stop` 下把它当终止错误，发布会在“打标签”这步中断（0.1.9 首次发布时实测）；push / tag / fetch 现在统一走 `Invoke-ReleaseGit`（Continue + 只看退出码）。
- 验证：新增 `tests\Test-Strata-Launcher-EngineConfigPath.ps1`；40 个 PowerShell 与 139 个 Python 测试通过；本机实测把 DeepSeek 配置改回已删除的 `0.1.49.2`，打开启动器后被自动改到 `0.1.51`，模型启动 `/health loaded: true`。

## 0.1.9 — 2026-10-26

- 新增「更新引擎（Qwen）」：补上“官方更新不会把引擎升到最新”的缺口。官方 `UPDATE.bat` / `setup.py --update` 只在预编译引擎低于 `MIN_ENGINE` 时替换引擎，所以 Strata 0.2.6 随附的 Qwen 引擎 `0.1.50` 不会覆盖已装的 `0.1.48`（更新日志里的 `ready-made engine already installed` 是预期行为，不是失败）。
  - 按钮走官方签名更新源（`setup.engine_from_feed`，与官方 0.2 组件更新同一套校验：Ed25519 签名、逐文件哈希、试启动通过后才替换），不受 `MIN_ENGINE` 门槛限制；确认框写明当前引擎版本，旧引擎保留在 `engine\.previous`，回退用官方 `setup.py --rollback-engine`。
  - 只更新 `engine\`（Qwen3.6 / Qwen3.8 / Swift 模型使用的 Strata 引擎）；DeepSeek-V4.1-Flash 的 `engine-dsv41` 有旁边的独立按钮，见下面一条。
- `Strata-Launcher-Update.ps1` 新增 `-EngineOnly`：只更新引擎——不做源码快进、不运行 `UPDATE.bat`、不改模型配置与官方设置。
  - 本地编译引擎（`engine\BUILD.json` 的 `source=local`）拒绝被预编译包替换，提示用官方 `setup.py --build` 重新编译。
  - `engine\strata.exe` 正被占用（模型还在跑）时直接报错退出，不会半途替换。
  - 引擎已是签名源最新版时明确说“没有替换”，不把“无变化”报成失败。
  - 只有 DeepSeek 的安装点「更新引擎（Qwen）」会直接说明（没有 Qwen 引擎、也没有能试启动它的模型配置），不会先下载几百 MB 再失败。
- 更新脚本默认根目录改为与启动器相同的识别规则（父目录，或同级 `Strata`）；「官方更新」「更新引擎（Qwen）」「更新引擎（DeepSeek）」三个入口都显式传 `-StrataRoot`，在独立的 `Strata-Launcher` 开发目录里也能用。
- 「官方工具」布局改为四列：第 1 行「导入本地模型」「官方 START-HERE」「环境检查」「立即备份设置」，第 2 行「官方更新」「更新引擎（Qwen）」「更新引擎（DeepSeek）」「刷新模型列表」。
- DeepSeek-V4.1-Flash 的引擎是另一条链（`engine-dsv41\`、feed 成员 `dsv41`、`strata_control/dsv41_engine.py`）：官方 `UPDATE.bat` 和 `strata update` 都不管它，官方只在 DeepSeek 安装流程末尾（`setup.install_dsv41` → `setup.upgrade_dsv41_engine`）升它。新增「更新引擎（DeepSeek）」和 `-DeepSeekEngineOnly`，直接调用同一个升级函数：签名与逐文件哈希校验、只跑一次 `strata-dsv41 --version` 试启动，通过后新包与旧包短暂并存再删旧的一代（只保留一代，没有 `--rollback-engine`）。没有 DeepSeek 引擎的安装明确拒绝，不会顺手下载一个。
- 升级后自动修正模型配置：DeepSeek 的官方升级装到新的版本目录、随后删掉旧目录，但 `strata-*.json` 记的是引擎的绝对 `exe` 路径（还有 `lib_dirs`）——升级完模型就起不来（本机 2026-10-26 实测：引擎已是 0.1.51，配置仍指向 0.1.49.2，启动三次都失败）。更新成功后启动器会把配置里的旧引擎目录改成新目录，只替换这一条路径，文件其余字节不动。
- 断流自动续传：官方下载器在一次运行内不重试（连接一断就以“装不上”结束，但残片保留）。启动器对两个引擎的更新都做最多 4 次续传（按残片接着下，已实测 CDN 支持 `Range`），并把官方给出的失败原因原样抛出，不再含糊地报“或本次更新未完成”。
- 官方更新链上的三个坑（本机实测，Strata 0.2.6 + 引擎 0.1.50）：
  - 签名源默认按 id 挑一个已装模型做试启动，本机会挑到 DeepSeek 的配置，把 `--eos` 等 dsv41 参数交给 Qwen 引擎（`unknown argument: --eos` 后退出），看起来像引擎坏了。启动器现在显式传 `--model-config`，只选启动 `engine\strata.exe` 的配置。
  - 那次失败会在签名源里留下 24 小时的“试启动失败”标记（不加 `--force` 不再尝试）。启动器只在“试启动失败”时用一次 `--force` 重试；被回滚过（rolled back）的版本不强行覆盖。
  - 更新必须写进 `setup.home()\engine-feed`（`engine_from_feed` 随后从这里复制到 `engine\`）。用默认的按用户组件目录会出现“下载并试启动成功、但 `engine\` 版本没变”。
- 验证：139 个 Python 测试与 39 个 PowerShell 测试通过（新增 `tests\Test-Strata-Launcher-EngineOnly.ps1`：预编译引擎走签名源、不碰 `UPDATE.bat`、本地编译引擎被拒）；在临时安装目录上用替身 Python 实测 `0.1.48 → 0.1.50`、`0.1.50 → 0.1.50`（无变化）、“引擎被占用”、“本地编译被拒”，以及 DeepSeek 的 `0.1.49.2 → 0.1.51`、无 DeepSeek 引擎被拒、断流后自动续传（桥被调用 2 次）三条路径；`-ExpandAllSections` 实窗口确认新按钮与四列布局。**实机验收：本机 Strata v0.2.6 的 Qwen 引擎由 `0.1.48` 升级到 `0.1.50`（`engine\.previous` 保留 `0.1.48`）；DeepSeek 引擎由 `0.1.49.2` 升级到 `0.1.51`，升级后用它真实启动模型，`/health` 报 `loaded: true`（`-CheckOnly` 报 `engine_version=0.1.50`、`deepseek_engine_version=0.1.51`）。**

## 0.1.8 — 2026-10-24

- DeepSeek 的专家放置参数全部开放（此前只有 `--ssd-cache` 一项），每一项都带说明、范围或预设：
  - `--ssd-policy`（lru / lfu / lfu→lru）、`--mmap-experts`（auto / on / off）、`--vram-experts`（0–1）、`--dspark-block`（0–8）。枚举走下拉，数值走限定范围的数字框；越界或非法值不写进配置（dsv41 遇到坏参数会直接退出）。
  - 互斥保护：选「拷进内存」（`--mmap-experts off`）时自动把 `--ssd-cache` 置 0 —— 拷贝和内存池都会占内存，叠加等于双倍开销。
  - 新增「性能预设」：**自动（均衡）** / **尽可能快（多吃内存）** / **省内存（少占内存）**。快的预设给出的是**本机现算**的专家缓存值：min(可用物理内存 − 12 GB, 物理内存 × 0.6)，上限 256 GB，保存时按当时的可用内存再算一次（手填的数字不动）；读不到内存或可用不足 8 GB 时**不显示这个预设**，也不编造数字。改任一项自动显示「自定义」。
  - `--ssd-cache` 增加 1024 GB 上限校验；提示里直接给出本机建议值。
- **实机验收**（本机 256 GB / 2×RTX 3090 / DeepSeek 2.00bpw）：内存池从 `auto` 的 48 GB（4672 槽，LRU）改为 153 GB（14893 槽，LFU）后，CPU 侧 13,897 个专家全部驻留内存（预载 107.9 GB / 31 s），空闲读盘由 1.2 GB/s 降为 0 MB/s，生成速度 10.71 → 20.50 tok/s（+91%）。
  - 验证：37 个 PowerShell 测试通过（新增建议值、域校验、互斥与预设标签用例）；WinForms 冒烟脚本与 `-ExpandAllSections` 实窗口加载确认控件及提示渲染正确。**未做**长对话与停止验收。

## 0.1.7.5 — 2026-10-24

- 完整适配 DeepSeek-V4.1-Flash（`deepseek41`，独立引擎 `strata-dsv41`），与 Qwen 模型共用同一个启动器，按当前模型自动切换规则：
  - 双引擎识别（`arch` 或 `engine-dsv41` 路径）；环境检查允许“只有 DeepSeek 引擎”的安装；主界面版本行显示所选模型的引擎。
  - 导入预检识别多文件分片与共享文件；运行参数只写 dsv41 支持的项（`--reserve-mib`、`--cpu-threads`、`--dspark`、`--dspark-conf`、`--ssd-cache`、`--prefill-chunk`、`--tp`），剔除 Qwen 专用参数。
  - 多卡：选择参与推理的显卡（写配置 `gpu`）与 `--tp`，不写 Qwen 的 `gpu_roles`/`layer_split`。
  - 上下文：8K（官方默认）/16K/32K/64K 原生/128K–1M（YaRN ×2–×16，更大的均标未验证）。
  - 停止服务同时识别 `engine\strata.exe` 与 `engine-dsv41\<版本>\strata-dsv41.exe`。
  - 原“性能校准”对 DeepSeek 变为「官方调优」（`tools/dsv41/tune.py`）；新增「规划预测」（`strata launch --plan`，只读）。
  - DeepSeek 下禁用 Qwen 口径的批量 Benchmark、视觉、并行请求，并写明原因。
- 官方更新：无上游分支时也会采用带发布说明的最新官方标签（例如 v0.2.4.2），不再被“Release 页面仍是 v0.2.4”卡住。
- 模型标签显示 `DeepSeek-V4.1-Flash`，多套时自动加配置名后缀。
- 验证：139 个 Python 测试与 37 个 PowerShell 测试通过；本机 Strata `v0.2.4.2` / 引擎 `0.1.48` / DeepSeek 引擎 `0.1.49.2`；DeepSeek 官方导入与 16 token 冒烟测试通过。**启动器内的完整加载、长对话与停止仍未做完整验收。**
## 0.1.7.5-dev.5 — 2026-10-24（未发布）

- 按“从功能到引擎”完整审核后的修正：
  - 环境就绪不再强制要求 Qwen 引擎：只有 DeepSeek 引擎 + DeepSeek 配置时启动器也能打开；`-CheckOnly` 增加 `deepseek_engine_version`。
  - 主界面版本行按所选模型显示对应引擎：DeepSeek 显示 `DeepSeek 引擎 0.1.49.2`，Qwen 仍显示 Qwen 引擎。
  - 停止/进程识别的引擎路径支持 `engine-dsv41\<版本>\strata-dsv41.exe`（此前只认 `engine-dsv41\strata-dsv41.exe`，而实际安装是带版本子目录的，导致引擎身份校验找不到进程）。
  - 模型标签显示 `DeepSeek-V4.1-Flash`（多套时自动加配置名后缀）。
  - 支持矩阵文档更新为审核后的完整状态。
- 验证：139 个 Python 测试、37 个 PowerShell 测试通过；新增 DeepSeek 引擎包/版本/路径识别测试；`-CheckOnly` 输出 `deepseek_engine_version=0.1.49.2`；界面版本行实测显示 “DeepSeek 引擎 0.1.49.2”。
## 0.1.7.5-dev.4 — 2026-10-24（未发布）

- DeepSeek 上下文选项从 8K–64K 扩到 8K–1M：8K 官方默认、64K 原生，128K/256K/512K/1M 为 YaRN ×2/×4/×8/×16（均标未验证；KV 显存随上下文增长）。
- 依据：GGUF 元数据 `context_length=1048576`、`rope.scaling.factor=16`、`original_context_length=65536`；引擎 `--max-context` 不设上限。官方文档只验证 8192，所以更大的都标“未验证”。
- 上下文摘要对 DeepSeek 按 64K 原生 / YaRN 换算，不再误用 Qwen 的 262144 基准。
## 0.1.7.5-dev.3 — 2026-10-24（未发布）

- DeepSeek 的性能入口改用官方工具：原“保存并校准”按钮对 DeepSeek 变为「官方调优」，运行官方 `tools/dsv41/tune.py --config <配置> --mode quick`（与 `strata launch --tune quick` 同一条路径），结果写入当前配置。
- 新增「规划预测」按钮：运行 `strata launch --model <规格> --family deepseek41 --data-dir <数据目录> --plan`，只读显示显卡/RAM 分配与预计速度（输出里明确 “Nothing was changed”）。
- DeepSeek 下「批量 Benchmark」禁用并说明原因（Qwen 口径的上下文档位/Needle/并发不适用）。
- 模型规格从配置文件名解析（`strata-deepseek-v4.1-flash-ist-das-2.00bpw.json` → `ist-das-2.00bpw`），并加入单元测试。
- 验证：139 个 Python 测试、36 个 PowerShell 测试通过；用真实 DeepSeek 配置打开界面确认两个按钮与说明；`strata launch --plan` 实跑确认只读。
## 0.1.7.5-dev.2 — 2026-10-24（未发布）

- 修正官方更新在“没有上游分支”时的判定：官方补丁版（0.2.4.1、0.2.4.2…）只有标签与发布说明，GitHub “latest release” 仍指向 0.2.4；启动器现在会在 Release 页面版本之后，再取带 `docs/release-notes-<版本>.md` 的最新官方标签并快进，避免“有新补丁却显示已是最新”。
- 该路径仍只做 `--ff-only`；标签没有发布说明时不采用，保持原有安全边界。
- 批量 Benchmark 的模型选择测试按“排除 DeepSeek 配置”更新期望值。
- 本机 Strata 源码已快进到 v0.2.4.2（含官方 #3927/#3917 的 Qwen mmproj 修复）；引擎保持 0.1.48 预编译（≥ MIN_ENGINE 0.1.46）。
## 0.1.7.5-dev.1 — 2026-10-24（未发布）

- 按“按模型识别、只启用受支持项”的方式补齐 DeepSeek 适配，逐项对照见 `docs/deepseek-support-matrix.md`。
- 多卡：DeepSeek 可选择参与推理的显卡（写配置 `gpu`，服务器据此设置可见显卡），不再写 Qwen 的 `gpu_roles`/`gpu_order`/`layer_split`；新增张量并行 `--tp`（自动/1/2）。
- 停止服务：进程树同时识别 `engine\strata.exe` 与 `engine-dsv41\strata-dsv41.exe`。
- 性能校准：DeepSeek 下禁用并提示使用官方 `strata launch --tune`。
- 批量 Benchmark：DeepSeek 模型不再出现在模型列表（Qwen 口径的上下文/Needle/并发假设不适用）。
- 验证：139 个 Python 测试、35 个 PowerShell 测试通过；用临时 DeepSeek 配置确认界面显示“参与推理”“张量并行 --tp”，校准区显示官方调优提示。

## 0.1.7.4 — 2026-10-24

- 修正 0.1.7.3 的两个默认值问题：官方没有写 `--dspark-conf` 时（如 Unsloth UD-Q8_K_XL），启动器不再自动补 0.65；现在留空即保留官方值/引擎默认。
- `--ssd-cache` 留空或填 `auto` 都不写该参数，只接受 GB 数字；保存时校验 DSpark 置信度（0–1）与 SSD 缓存输入，填错会明确报错，不写入无效参数。
- DeepSeek 的可调参数纳入 `user_args` 同步：官方配置里已有的 `--dspark` 等用户覆盖项，启动器修改后会同步覆盖，避免“改了却仍按旧值运行”。
- 启动器没有编辑的引擎参数（`--tp`、`--vram-experts`、`--ssd-policy`、`--mmap-experts` 等）原样保留。
- 验证：139 个 Python 测试与 35 个 PowerShell 测试通过；新增用例覆盖“缺失的 `--dspark-conf` 保持缺失”“`--tp`/`--vram-experts` 保留”“user_args 同步”；用临时 DeepSeek 配置确认置信度与 SSD 缓存默认为空。

## 0.1.7.3 — 2026-10-24

- 完整适配 DeepSeek-V4.1-Flash 的命令行（`deepseek41` / `strata-dsv41`）：保存与启动时不再写入 Qwen 引擎专用的 `--kv`、`--kv-resident`、`--vram-reserve-mib`、`--pool-workers`、`--rope-scaling`、`--rope-scale`，避免 dsv41 把未知参数当成致命错误（退出码 2）。
- DeepSeek 模型改为显示并使用自己的运行参数：上下文（8192 为官方默认）、显存预留 `--reserve-mib`、CPU 线程 `--cpu-threads`、DSpark 草稿 `--dspark`、草稿置信度 `--dspark-conf`、SSD 专家缓存 `--ssd-cache`、预填充分块 `--prefill-chunk`；官方写入的 `--pack`、`--eos`、`--expert-profile` 原样保留。
- DeepSeek 下隐藏不适用的选项：KV cache 格式、驻留 KV、并行请求（官方会忽略）、视觉、显卡角色分配（引擎自行安排专家分层）；这些控件不再参与保存。
- 验证：139 个 Python 测试与 35 个 PowerShell 测试通过；新增 DeepSeek 参数测试覆盖官方参数集的读写；用临时 DeepSeek 配置打开界面，确认显示上述控件、且不出现 KV/并行行。DeepSeek 的完整推理仍未在本机验收。

## 0.1.7.2 — 2026-10-24

- 修正 0.1.7.1 的多文件预检：把 Engram、DSpark 草稿和 UD-Q8_K_XL 的元数据分片与 IST-DAS 分片放在同一目录时，旧逻辑会误报“找到多个模型”。
- 原因：元数据分片 `DeepSeek-V4.1-Flash-1017-UD-Q8_K_XL-00001-of-00009.gguf` 同时是 UD-Q8_K_XL 的第 1 片，被当成了第二个模型。
- 现在按命中的分片数量判断：4 个 IST-DAS 分片胜过 1 个 UD 元数据分片；两套模型的分片数量相同时仍按“多个模型”拒绝。
- 验证：139 个 Python 测试与 34 个 PowerShell 测试通过；本机把 4 个分片、Engram、DSpark 和元数据分片放进同一目录后，预检识别为 `deepseek41 / IST-DAS-2.00bpw`。

## 0.1.7.1 — 2026-10-24

- 本地模型导入的预检支持 DeepSeek-V4.1-Flash 这类多文件模型族：按官方分片文件名识别模型与版本，核对分片是否齐全、大小是否与官方一致，再交给官方 setup 继续校验并补齐共享文件。
- 此前预检只认识单文件族，选择 DeepSeek 分片目录会直接报“没有匹配的 GGUF 文件名”，官方 setup 不会启动；本版修复该误报。
- 单文件族（Qwen3.8、Swift、Unsloth、Qwen3.6）的识别与校验逻辑不变。
- 验证：139 个 Python 测试与 34 个 PowerShell 测试通过；用本机 DeepSeek-V4.1-Flash IST-DAS 2.00bpw 的 4 个分片目录实测识别为 `deepseek41 / IST-DAS-2.00bpw`。DeepSeek 模型本体之外，官方 setup 仍需下载共享文件与专用引擎，本版不改变官方下载流程。

## 0.1.7 — 2026-10-24

- 为一个模型新增 NVIDIA 多卡分层配置：按卡选择 Main、Helper、Off；写入 Strata 的 `gpu_roles`、`gpu`、`gpu_order`，多卡时使用自动分层。GPU 角色区域以 Windows 十进制 PCI 总线位置区分同型号显卡。
- 新增独立的 Strata Monitor 悬浮窗：从官方只读遥测接口显示生成速度、每张 GPU 的负载与显存、系统内存和近期请求摘要，不显示请求正文；可调透明度、始终置顶，鼠标穿透可通过系统托盘解除或退出，服务未启动或断线时显示状态并重试。
- 适配 Strata `v0.2.4` 的引擎版本规则：官方 Qwen 预编译引擎按 `setup.py` 的 `MIN_ENGINE` 判断兼容性，本地编译引擎仍与源码构建目标比较，避免把 0.1.49 源码目标误判成必须升级的 Qwen 引擎。
- 更新脚本新增 `-VerifyOnly`：核对 `BUILD.json`、可执行文件版本和兼容下限，不触发源码或安装更新；签名源补装只在预编译引擎低于官方下限时运行。
- 主界面同时显示 Strata 源码版本、引擎版本和启动器版本，`-CheckOnly` 输出对应版本字段；源码没有可识别的 Git 版本标签时显示“未知”。
- 生成参数、运行设置、显卡分配、网络、显卡功率和工具整理为可折叠分组，并记住各分组的展开状态；显卡功率信息在展开时读取，性能校准摘要改为展开工具分组时计算，停止服务所需的进程树辅助代码改为按需加载。
- 验证：138 个 Python 测试与 34 个 PowerShell 测试通过；本机 `-CheckOnly` 在 Strata `v0.2.4` / 引擎 `0.1.48` 上就绪（3 个模型可用）。双卡 NVIDIA 分层已在本机真实模型推理中验收；**完整日常推理未在本版重新验收。**

## 0.1.7-dev.3 — 2026-10-24

- 主界面同时显示 Strata 源码版本、引擎版本和启动器版本；`-CheckOnly` 输出对应版本字段。源码没有可识别的 Git 版本标签时显示“未知”。
- 将生成参数、运行设置、显卡分配、网络、显卡功率和工具整理为可折叠分组，记住各分组的展开状态。
- 显卡功率信息在展开对应分组时读取，性能校准摘要在展开工具分组时计算；停止服务所需的进程树辅助代码改为按需加载，减少首屏前的工作。

## 0.1.7-dev.2 — 2026-10-24

- 适配 Strata v0.2.4 的引擎版本规则：官方 Qwen 预编译引擎按 `setup.py` 的 `MIN_ENGINE` 判断兼容性，本地编译引擎仍与源码构建目标比较；避免把 0.1.49 源码目标误判成必须升级的 Qwen 引擎。
- 更新脚本新增 `-VerifyOnly`，核对 `BUILD.json`、可执行文件版本和兼容下限，不触发源码或安装更新；签名源补装只在预编译引擎低于官方下限时运行。
- 新增独立的 Strata Monitor 悬浮窗：从官方只读遥测接口显示生成速度、每张 GPU 的负载与显存、系统内存和近期请求摘要；不显示请求正文。
- 悬浮窗可调透明度，始终置顶，可启用鼠标穿透；穿透状态可通过系统托盘解除或退出。服务未启动或断线时显示状态并重试，不代替原有浏览器监控入口。
- 本机两张 RTX 3090 的多卡推理已通过隔离配置验证；GPU 角色区域以 Windows 十进制 PCI 总线位置区分同型号显卡。

## 0.1.7-dev.1 — 2026-10-24

- 为一个模型新增 NVIDIA 多卡分层配置：按卡选择 Main、Helper、Off；写入 Strata 的 `gpu_roles`、`gpu`、`gpu_order`，多卡时使用自动分层。
- 未明确勾选“修改当前模型的推理显卡分配”时，保存其他设置不会改动原有 GPU 选择。写入前重新核对 CUDA 引擎、显卡身份、角色数量与多卡显存下限。
- 本机双卡真实模型推理验收已完成；记录见 `docs/superpowers/verification/2026-10-24-multi-gpu-live.md`。通过了离线配置、界面显示与打包检查。

## 0.1.6 — 2026-10-23

- 官方更新改由启动器更新脚本执行：有上游分支时只做快进拉取；没有上游时只跟随 Strata 官方最新稳定 Release，不会误拉未发布的 `main` 代码；不能快进时安全停止并保留本地改动。
- 引擎版本检查：对照官方源码的引擎目标版本核对 `engine/BUILD.json` 与 `strata.exe --version`；旧引擎显示警告但仍可启动，缺少安装信息时提示先检查更新，避免把部分更新显示为成功。
- 模型列表刷新会检查配置引用的 GGUF 和专家包；组件缺失的模型暂时隐藏且不删除配置，恢复文件后刷新即可重新出现；启动和切换前也会再次检查。
- 停止 Strata 时不再把“进程已自行退出”报成停止失败（taskkill 退出码 128）；根进程消失但 Python 服务或引擎仍在运行时会明确报错并列出剩余 PID。
- 运行时设置新增「CPU 线程数」（引擎的 `--pool-workers`）：0 表示自动（物理核心 − 1，上限 32）；保存时写入模型配置，设为 0 恢复自动。
- 修正主脚本与校准视图的 UTF-8 BOM，避免 Windows PowerShell 5.1 按 ANSI 解码中文导致乱码或解析失败。
- 本版针对 Strata `v0.2.3` / 引擎 `0.1.48` 完成更新与一词生成验证，134 个 Python 测试及相关 PowerShell 测试通过；完整日常推理尚未验收。

## 0.1.6-dev.4 — 2026-10-23

- 运行时设置新增「CPU 线程数」（引擎的 `--pool-workers`）：0 表示自动（物理核心 − 1，上限 32）；超过核心数的值可能让模型更慢。
- 保存时把该值写入模型配置的 `args`，并纳入启动器的参数管理，旧的 `user_args` 覆盖会被同步；设为 0 会移除该参数、恢复引擎自动选择。

## 0.1.6-dev.3 — 2026-10-23

- 停止 Strata 时，如果进程在确认期间已自行退出（taskkill 退出码 128），按“已停止”处理并只检查端口，不再报停止失败。
- 根进程已消失但 Python 服务或模型引擎仍在运行时，仍会明确报错并列出剩余 PID；启动器不会盲目结束其它进程。
- 修正 `Strata-Launcher.ps1` 与 `Strata-Calibration-View.ps1` 的 UTF-8 BOM：避免 Windows PowerShell 5.1 按 ANSI 解码中文脚本，导致乱码或解析失败。

## 0.1.6-dev.2 — 2026-10-23

- “官方更新”改由启动器更新脚本执行：有上游分支时只做快进拉取；没有上游时只跟随 Strata 官方最新稳定 Release，不会误拉未发布的 `main` 代码。
- Git 分支不能快进时明确停止并保留本地改动；源码更新后调用官方 `START-HERE.bat --update`，若其跳过新版引擎，再调用官方签名更新源；最后核对 `engine/BUILD.json`、`strata.exe --version` 与源码目标版本，避免把部分更新显示为成功。
- 本机通过运行目录中与按钮相同的命令链，将 Strata 源码从 `v0.2.2` 快进到 `v0.2.3`、旧引擎从 `0.1.47` 更新到 `0.1.48`；签名更新源记录一词生成测试成功。

## 0.1.6-dev.1 — 2026-10-23

- 刷新模型列表时重新检查配置引用的 GGUF 和专家包；组件已删除的模型从可选列表暂时隐藏，配置文件保持原样，恢复组件后再次刷新即可出现。
- 当前选择已失效时，刷新会改选仍可用的模型；切换和启动前再次检查模型组件，避免窗口打开后模型被移走却继续使用旧选择。
- 按官方 `setup.py` 的目标版本检查 `engine/BUILD.json`；旧引擎显示警告并遵循官方回退策略继续可用，缺少安装信息时提示先检查更新。
- 对本机 Strata `v0.2.2` 源码的模型目录、运行配置和 GPU 角色机制完成静态核对与离线测试；新版引擎安装及实际推理待验收。

## 0.1.5 — 2026-10-21

- 识别 Strata 0.2.1 的 `user_args` 优先级：界面显示实际生效的引擎参数，保存时同步用户覆盖项并记录 `args_written`，避免显示值与启动值不一致。
- Benchmark 从有效参数生成报告目录中的临时配置，并移除临时配置里的 `user_args`，防止它覆盖所选上下文、显存、视觉等统一测试条件；原始模型配置保持不变。
- 明确包仅适用于 Windows `START-HERE.bat` 源码安装，不适用于官方 App 或独立 Terminal。兼容性验证为离线测试与环境检查，尚未完成新版引擎的实机启动和推理验收。

## 0.1.4 — 2026-10-17

- 将 Benchmark 使用的 Needle 与并发测试脚本作为启动器仓库的版本化源码保存，便携包直接从该源码构建；独立检出启动器时不会误打包 Strata 根目录中的旧脚本。
- 修正包内 Needle 脚本的语料根目录，使其读取当前安装的 Strata 文档和源码，避免从 `launcher/benchmark` 下寻找空语料。
- 支持把启动器开发仓库放在 Strata 安装目录外，通过同步脚本仅更新运行副本的程序文件，保留本机数据与报告。

## 0.1.3 — 2026-10-16

- Benchmark 的截图概览与分享图按本次实际选中的项目生成；性能输入和并发输入分别标注，未选择容量探测时不再显示空的“上下文容量”结果。
- 截图概览加入缓存预填充与复用 token、内置 Agent 题集口径和并发实测槽数；不再把预设语料词数当作真实输入长度展示。
- 完整网页报告的 Agent 题数从本次清单读取，不再固定写成旧版 7/9 道；已保存的 HTML 属于静态快照，可从原始记录重新生成。

## 0.1.2 — 2026-10-16

- 主启动器使用预设调整为“快速直答、日常通用、Agent / 深度思考”三档：快速直答采用 Qwen 官方非思考采样值，另外两档采用思考采样值；三档均清除旧的输出、思考上限及固定种子，只改生成参数，不触碰模型运行与显存设置。修正手动修改参数后仍显示原预设的问题，并在保存时写入模型默认思考强度。
- Benchmark 分为“日常速测、日常完整、长文对照、并发专项、容量极限”五档；将原先混在长文压力中的 128K/256K 冷输入、长文双路并发与容量探测拆开。预设同步设置轮数、原生 256K 上限、输入和项目；旧版保存的昂贵矩阵按新预设迁移，原模型配置不变。旧 CLI `stress` 会提示改选新档，避免同名预设含义被悄悄改变。
- 修正取消全部模型上限后又被后端自动补回 256K 的问题；源配置上限、YaRN/ROPE 缩放须在所选模型间一致，且上限足以容纳输入。选中的召回或并发项目若没有可运行输入，现在在启动前报错。
- “逐档完整测试”改为“多档上限测试”：普通模式只能选一个上限，多档模式至少选两个；不再暗中忽略多选档位。启动确认显示含缓存与并发阶段重启的计划启动次数及工作量，跳过没有适用输入的并发阶段重启。
- 1K 性能输入在校准时计入正式请求标识，继续以服务端实际 token 数判定有效性；报告显示中文预设名称。
- Benchmark 按当前模型 tokenizer 校准 32K 缓存与各档 Needle 输入；性能、缓存、稳定性要求有效输出，召回率分母计入失败或缺失的应测题，容量证据不足时显示部分完成。报告补充这些判定口径，并提供可直接分享的一句话总结与精简 Markdown 对照数据。
- 分享 ZIP 随包携带本版 Needle 与并发测量脚本；Benchmark 优先使用包内版本，不修改接收者 Strata 根目录的官方工具。并发报告核验实测输入、冷提示词和输出时间重叠。

## 0.1.1 — 2026-10-15

- 首次勾选“启用图像输入”时，启动器从当前模型的 `--native` GGUF 路径查找对应的已安装 `mmproj`，依据 `engine/BUILD.json` 选择 GPU 或 CPU 编码，写入视觉配置并添加 `--vision`；已有主配置或 `.vision.json` 中的自定义视觉设置优先。
- 视觉复选框以主配置的启用状态为准；仅保存备用 `.vision.json` 时不再显示为已启用。缺少视觉程序、模型或编码器时，报错显示具体缺失路径。
- 分享 ZIP 的文件名包含 `VERSION.txt` 中的启动器版本号，方便区分不同版本。

## 0.1.0 — 2026-10-14

### 官方版本适配

- 适配 Qwen3.6-35B-A3B 的独立架构、MTP、预填充与专家显存参数；该模型的上下文选择限制为官方支持的 256K 以内。
- 本地模型导入按当前安装的官方 `setup.py` 识别模型系列与量化规格，并交由官方安装流程完成最终校验。
- Benchmark 的原生模型上下文档位遵循官方限制；临时测试配置不会覆盖用户保存的专家配置。

### 模型显示与启动速度

- 修复 Flash-Next 被误识别为 Qwen3.6 的问题。显示名从当前安装的官方模型清单提取，区分量化来源；只改变界面文字，不改模型文件、配置中的 `model_name` 或 Benchmark 原始记录。
- 官方清单按 `setup.py` 和提取脚本的内容缓存；新增本地模型配置仍在每次打开时扫描。缓存命中约 6 毫秒，重新提取约 226–257 毫秒（本机测量）。
- 批量处理界面布局；本机启动脚本运行到显示窗口前约 2.14–2.22 秒。模型选择框收起宽度为 340 像素、展开宽度为 360 像素；顶部名称过长时显示省略号，悬停可看全名。

### Benchmark 报告

- 扩充 Markdown 报告的工作负载、模型与配置快照、硬件和驱动、逐阶段覆盖及逐项测量信息，并链接完整原始记录与日志。报告保留各维度数据，不生成单一总分。

### 验证范围

- 已通过 79 个 Python 测试、20 个 PowerShell 测试、便携打包检查和 `-CheckOnly`。本次版本整理没有写入本机模型配置。
- 本机未安装 Qwen3.6 模型，未进行该模型的真实推理验收；界面耗时测到显示窗口之前，未测实际首帧。
